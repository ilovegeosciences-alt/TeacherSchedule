package com.teacher.schedule

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

// ====== iOS Cupertino 视觉色彩系统 (专为安卓安装应用打造的 iOS 风格配色) ======
val IosSystemBg = Color(0xFFF2F2F7)          // iOS 系统分组浅灰背景
val IosCardBg = Color(0xFFFFFFFF)            // iOS 纯白内嵌卡片
val IosNavBlurBg = Color(0xF5F9F9FB)         // iOS 顶部/底部毛玻璃导航底色
val IosBlue = Color(0xFF007AFF)              // iOS 系统蓝 (#007AFF)
val IosGreen = Color(0xFF34C759)             // iOS 翡翠绿 (#34C759)
val IosIndigo = Color(0xFF5856D6)            // iOS 靛紫 (#5856D6)
val IosOrange = Color(0xFFFF9500)            // iOS 活力橙 (#FF9500)
val IosRed = Color(0xFFFF3B30)               // iOS 珊瑚红 (#FF3B30)
val IosLabelPrimary = Color(0xFF1C1C1E)      // iOS 主标题深黑
val IosLabelSecondary = Color(0xFF8E8E93)    // iOS 次要文字灰
val IosSeparator = Color(0xFFE5E5EA)         // iOS 0.5dp 细分割线
val IosSegmentedBg = Color(0x1F767680)       // iOS 分段控制器槽背景

// Apple iOS HIG 10色课程调色板（每门课自动分配不同颜色）
val COURSE_COLOR_PALETTE = listOf(
    "#007AFF", // iOS Blue
    "#34C759", // iOS Green
    "#5856D6", // iOS Indigo
    "#FF9500", // iOS Orange
    "#FF2D55", // iOS Pink
    "#30B0C7", // iOS Teal
    "#AF52DE", // iOS Purple
    "#FF3B30", // iOS Red
    "#00C7BE", // iOS Mint
    "#A2845E"  // iOS Brown
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = IosBlue,
                    secondary = IosIndigo,
                    background = IosSystemBg,
                    surface = IosCardBg,
                    onPrimary = Color.White,
                    onBackground = IosLabelPrimary,
                    onSurface = IosLabelPrimary
                )
            ) {
                TeacherScheduleIosStyleApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherScheduleIosStyleApp() {
    val context = LocalContext.current
    var totalWeeks by remember { mutableIntStateOf(20) }
    var currentWeek by remember { mutableIntStateOf(7) }
    var semesterStartMonday by remember { mutableStateOf(LocalDate.of(2026, 9, 7)) }
    var activeTab by remember { mutableIntStateOf(0) } // 0: 课表网格, 1: 提前提醒, 2: 桌面小组件, 3: 备课清单, 4: 作息设置
    var showAddSheet by remember { mutableStateOf(false) }
    var editingCourse by remember { mutableStateOf<CourseEntity?>(null) }
    val converters = remember { Converters() }

    // 默认一天 11 节课（上午4节8:10起、下午4节14:30起、晚上3节19:10起，每节45分钟；2-3节间30m，6-7节间20m，其余5m课间）
    var sectionSlots by remember { mutableStateOf(AlarmScheduler.default11Sections) }

    var courses by remember {
        mutableStateOf(
            listOf(
                CourseEntity(
                    id = 1L,
                    courseName = "高等数学 (上)",
                    colorHex = "#007AFF",
                    credits = "4.0学分",
                    campusNote = "东校区 教三-204",
                    teacherName = "林教授",
                    studentCount = "64人",
                    majorAndClass = "计算机科学与技术 2401-02班",
                    prepChecklist = "带第4章微分中值定理板书讲义、随堂测验卷（多媒体带转接头）",
                    timeSlotsJson = converters.toTimeSlotsJson(
                        listOf(
                            CourseTimeSlot(
                                slotId = "s1",
                                dayOfWeek = 1,
                                startSection = 1,
                                endSection = 2,
                                weeks = (1..20).toList(),
                                classroom = "东校区 教三-204",
                                classGroup = "计算机科学与技术 2401-02班"
                            ),
                            CourseTimeSlot(
                                slotId = "s2",
                                dayOfWeek = 3,
                                startSection = 3,
                                endSection = 4,
                                weeks = (1..20).toList(),
                                classroom = "东校区 教三-204",
                                classGroup = "计算机科学与技术 2401-02班"
                            )
                        )
                    ),
                    remindersJson = converters.toRemindersJson(
                        listOf(
                            ReminderRule(id = "r1", label = "提前2天", mode = "RELATIVE", daysBefore = 2),
                            ReminderRule(id = "r2", label = "课前30分钟", mode = "RELATIVE", minutesBefore = 30)
                        )
                    )
                ),
                CourseEntity(
                    id = 2L,
                    courseName = "机器学习导论",
                    colorHex = "#34C759",
                    credits = "3.0学分",
                    campusNote = "西校区 信息楼-402",
                    teacherName = "林教授",
                    studentCount = "48人",
                    majorAndClass = "人工智能专业 2301班",
                    prepChecklist = "跨西校区上课；提前2天检查实验服务器Jupyter环境",
                    timeSlotsJson = converters.toTimeSlotsJson(
                        listOf(
                            CourseTimeSlot(
                                slotId = "s3",
                                dayOfWeek = 4,
                                startSection = 5,
                                endSection = 7,
                                weeks = (1..18).toList(),
                                classroom = "西校区 信息楼-402",
                                classGroup = "人工智能专业 2301班"
                            )
                        )
                    ),
                    remindersJson = converters.toRemindersJson(
                        listOf(
                            ReminderRule(id = "r3", label = "提前2天", mode = "RELATIVE", daysBefore = 2),
                            ReminderRule(id = "r4", label = "课前1小时", mode = "RELATIVE", hoursBefore = 1)
                        )
                    )
                )
            )
        )
    }

    val calendarPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.WRITE_CALENDAR] == true &&
            perms[Manifest.permission.READ_CALENDAR] == true
        if (granted) {
            val count = SystemCalendarSyncHelper.syncCoursesToSystemCalendar(
                context = context,
                courses = courses,
                semesterStartMonday = semesterStartMonday,
                sections = sectionSlots
            )
            Toast.makeText(context, "已将 $count 次课程及提前备课提醒写入手机系统日历！", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "需要授予日历读写权限才能同步系统日历", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = IosSystemBg,
        topBar = {
            // iOS 风格毛玻璃导航栏 + Segmented Control 分段控制器
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(IosNavBlurBg)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(IosBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("师", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "◀",
                                    color = IosBlue,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .clickable { if (currentWeek > 1) currentWeek-- }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                                Text(
                                    text = "第 $currentWeek 周",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = IosLabelPrimary
                                )
                                Text(
                                    text = "▶",
                                    color = IosBlue,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .clickable { if (currentWeek < totalWeeks) currentWeek++ }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "共 $totalWeeks 周 · 开学 $semesterStartMonday",
                                fontSize = 11.sp,
                                color = IosLabelSecondary
                            )
                        }
                    }

                    // 右侧 iOS 胶囊操作按钮组
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(IosBlue.copy(alpha = 0.12f))
                                .clickable {
                                    val hasPerm = ContextCompat.checkSelfPermission(
                                        context, Manifest.permission.WRITE_CALENDAR
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasPerm) {
                                        val count = SystemCalendarSyncHelper.syncCoursesToSystemCalendar(
                                            context = context,
                                            courses = courses,
                                            semesterStartMonday = semesterStartMonday,
                                            sections = sectionSlots
                                        )
                                        Toast.makeText(context, "已同步 $count 次课程至系统日历", Toast.LENGTH_LONG).show()
                                    } else {
                                        calendarPermissionLauncher.launch(
                                            arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
                                        )
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("同步日历", color = IosBlue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(IosBlue)
                                .clickable {
                                    editingCourse = null
                                    showAddSheet = true
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("+ 添加课程", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // iOS UISegmentedControl 风格分段切换器
                val segTitles = listOf("周课表网格", "提前提醒", "桌面小组件", "备课清单", "作息设置")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(IosSegmentedBg)
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    segTitles.forEachIndexed { idx, title ->
                        val selected = activeTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) Color.White else Color.Transparent)
                                .clickable { activeTab = idx }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) IosLabelPrimary else IosLabelSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            // iOS 底部 UITabBar + Home Indicator
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(IosNavBlurBg)
            ) {
                Divider(color = IosSeparator, thickness = 0.5.dp)
                NavigationBar(
                    containerColor = Color.Transparent,
                    tonalElevation = 0.dp,
                    modifier = Modifier.height(60.dp)
                ) {
                    val navItems = listOf(
                        Triple(0, "课表", Icons.Default.CalendarMonth),
                        Triple(1, "提醒", Icons.Default.NotificationsActive),
                        Triple(2, "小组件", Icons.Default.Widgets),
                        Triple(3, "备课", Icons.Default.CheckCircle),
                        Triple(4, "设置", Icons.Default.Settings)
                    )
                    navItems.forEach { (idx, label, icon) ->
                        NavigationBarItem(
                            selected = activeTab == idx,
                            onClick = { activeTab = idx },
                            icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(20.dp)) },
                            label = { Text(label, fontSize = 10.sp, fontWeight = if (activeTab == idx) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = IosBlue,
                                selectedTextColor = IosBlue,
                                unselectedIconColor = IosLabelSecondary,
                                unselectedTextColor = IosLabelSecondary,
                                indicatorColor = Color.Transparent
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (activeTab) {
                0 -> IosTimetableGridTab(
                    courses = courses,
                    currentWeek = currentWeek,
                    sectionSlots = sectionSlots,
                    converters = converters,
                    onCourseClick = { c ->
                        editingCourse = c
                        showAddSheet = true
                    }
                )
                1 -> IosRemindersCenterTab(courses = courses, converters = converters)
                2 -> IosWidgetAndCalendarTab(
                    courses = courses,
                    currentWeek = currentWeek,
                    onPinWidget = {
                        val pinned = CourseWidgetProvider.requestPinWidgetToHomeScreen(context)
                        if (!pinned) {
                            Toast.makeText(context, "请长按安卓手机桌面空白处 -> 微件/小组件 -> 选择「师刻课表」添加桌面卡片", Toast.LENGTH_LONG).show()
                        }
                    }
                )
                3 -> IosPrepListTab(
                    courses = courses,
                    converters = converters,
                    onEditCourse = { c ->
                        editingCourse = c
                        showAddSheet = true
                    }
                )
                4 -> IosSettingsInlineTab(
                    currentStartMonday = semesterStartMonday.toString(),
                    currentTotalWeeks = totalWeeks,
                    currentSections = sectionSlots,
                    onSave = { newStartStr, newWeeks, updatedSections ->
                        runCatching { LocalDate.parse(newStartStr) }.getOrNull()?.let { semesterStartMonday = it }
                        totalWeeks = newWeeks.coerceIn(10, 30)
                        sectionSlots = updatedSections
                        Toast.makeText(context, "已保存学期与 11 节作息时间设置", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        if (showAddSheet) {
            val usedColors = courses.map { it.colorHex }.toSet()
            val defaultColor = COURSE_COLOR_PALETTE.firstOrNull { !usedColors.contains(it) }
                ?: COURSE_COLOR_PALETTE[courses.size % COURSE_COLOR_PALETTE.size]

            FullCourseAddDialog(
                initialCourse = editingCourse,
                totalWeeks = totalWeeks,
                defaultColorHex = defaultColor,
                onDismiss = {
                    showAddSheet = false
                    editingCourse = null
                },
                onDelete = { toDelete ->
                    courses = courses.filterNot { it.id == toDelete.id }
                    showAddSheet = false
                    editingCourse = null
                },
                onSave = { savedCourse ->
                    courses = if (editingCourse != null) {
                        courses.map { if (it.id == savedCourse.id) savedCourse else it }
                    } else {
                        courses + savedCourse
                    }
                    AlarmScheduler.scheduleCourseReminders(context, savedCourse, semesterStartMonday)
                    CourseWidgetProvider.updateAllWidgets(context)
                    showAddSheet = false
                    editingCourse = null
                }
            )
        }
    }
}

// ====== Tab 0: iOS 风格 7天 × 11节 周课表网格视图 ======
@Composable
fun IosTimetableGridTab(
    courses: List<CourseEntity>,
    currentWeek: Int,
    sectionSlots: List<SectionTimeSlot>,
    converters: Converters,
    onCourseClick: (CourseEntity) -> Unit
) {
    val weekDays = listOf("周一", "周二", "周三", "周四", "周五", "周六", "周日")
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 顶部 iOS 风格提前2天备课提醒胶囊提示条
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFFFFF8E7),
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, IosOrange.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "🔔 提前2天备课提醒已就绪 (AlarmManager 精确闹钟)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF9A5B00)
                    )
                    Text(
                        text = "轻点下方任意课程卡片可查看/修改 6 大课程属性、周数与多档提前提醒",
                        fontSize = 11.sp,
                        color = Color(0xFF7C4A03)
                    )
                }
            }
        }

        // iOS 圆角白色卡片包裹的 11 节周课表网格
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = IosCardBg,
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, IosSeparator, RoundedCornerShape(18.dp))
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                // 表头：节次 + 周一至周日
                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                    Text(
                        text = "节次",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = IosLabelSecondary,
                        modifier = Modifier.width(44.dp)
                    )
                    weekDays.forEach { dayName ->
                        Text(
                            text = dayName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IosLabelPrimary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Divider(color = IosSeparator, thickness = 0.5.dp)

                // 1-11 节行
                sectionSlots.forEach { sec ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.width(44.dp)) {
                            Text("${sec.section}节", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IosLabelPrimary)
                            Text("${sec.start}", fontSize = 9.sp, color = IosLabelSecondary)
                            Text("${sec.end}", fontSize = 9.sp, color = IosLabelSecondary)
                        }
                        for (day in 1..7) {
                            val matched = courses.firstOrNull { c ->
                                converters.parseTimeSlots(c.timeSlotsJson).any { s ->
                                    s.dayOfWeek == day && sec.section in s.startSection..s.endSection
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .padding(1.5.dp)
                            ) {
                                if (matched != null) {
                                    val slot = converters.parseTimeSlots(matched.timeSlotsJson).first {
                                        it.dayOfWeek == day && sec.section in it.startSection..it.endSection
                                    }
                                    val isCurrentWeek = slot.weeks.contains(currentWeek)
                                    val bgColor = if (isCurrentWeek) {
                                        Color(android.graphics.Color.parseColor(matched.colorHex))
                                    } else {
                                        Color(0xFFE5E5EA)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(bgColor)
                                            .clickable { onCourseClick(matched) }
                                            .padding(3.dp)
                                    ) {
                                        Text(
                                            text = "${matched.courseName}@${slot.classroom.ifBlank { matched.campusNote }}",
                                            fontSize = 9.sp,
                                            lineHeight = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isCurrentWeek) Color.White else IosLabelSecondary,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Divider(color = IosSeparator.copy(alpha = 0.5f), thickness = 0.5.dp)
                }
            }
        }
    }
}

// ====== Tab 1: iOS 风格多档提前提醒队列视图 ======
@Composable
fun IosRemindersCenterTab(courses: List<CourseEntity>, converters: Converters) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(courses) { course ->
            val rules = converters.parseReminders(course.remindersJson)
            val slots = converters.parseTimeSlots(course.timeSlotsJson)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = IosCardBg,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, IosSeparator, RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(course.courseName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = IosLabelPrimary)
                        Text(course.majorAndClass.ifBlank { "教师授课" }, fontSize = 12.sp, color = IosBlue, fontWeight = FontWeight.SemiBold)
                    }
                    slots.forEach { s ->
                        Text("周${s.dayOfWeek} 第${s.startSection}-${s.endSection}节 @ ${s.classroom.ifBlank { course.campusNote }} (共${s.weeks.size}周)", fontSize = 12.sp, color = IosLabelSecondary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        rules.forEach { r ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(IosOrange.copy(alpha = 0.14f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("🔔 ${r.label}", fontSize = 11.sp, color = Color(0xFFB45309), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ====== Tab 2: iOS 小组件风格安卓桌面卡片预览与添加 ======
@Composable
fun IosWidgetAndCalendarTab(
    courses: List<CourseEntity>,
    currentWeek: Int,
    onPinWidget: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color(0xFF1C1C1E),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("师刻课表 · 第 $currentWeek 周 (iOS深色毛玻璃小组件)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("安卓桌面微件", color = IosBlue, fontSize = 11.sp)
                }
                courses.forEach { c ->
                    Text("• ${c.courseName} | ${c.campusNote} | ${c.majorAndClass}", color = Color(0xFFE5E5EA), fontSize = 12.sp)
                }
                Button(
                    onClick = onPinWidget,
                    colors = ButtonDefaults.buttonColors(containerColor = IosBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("一键添加 iOS 风格小组件到安卓手机桌面", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

// ====== Tab 3: iOS Inset Grouped 课程属性与备课清单卡片 ======
@Composable
fun IosPrepListTab(
    courses: List<CourseEntity>,
    converters: Converters,
    onEditCourse: (CourseEntity) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(courses) { course ->
            val rules = converters.parseReminders(course.remindersJson)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = IosCardBg,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, IosSeparator, RoundedCornerShape(18.dp))
                    .clickable { onEditCourse(course) }
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(course.colorHex)))
                            )
                            Text(course.courseName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = IosLabelPrimary)
                        }
                        Text(course.credits.ifBlank { "未设学分" }, fontSize = 12.sp, color = IosBlue, fontWeight = FontWeight.SemiBold)
                    }
                    Text("地点：${course.campusNote.ifBlank { "未填" }}  |  老师：${course.teacherName.ifBlank { "本人" }}  |  人数：${course.studentCount.ifBlank { "未填" }}", fontSize = 12.sp, color = IosLabelSecondary)
                    Text("专业和班级：${course.majorAndClass.ifBlank { "未填" }}", fontSize = 12.sp, color = IosLabelPrimary)
                    if (course.prepChecklist.isNotBlank()) {
                        Text("备注/上课注意事项：${course.prepChecklist}", fontSize = 12.sp, color = Color(0xFF3A3A3C))
                    }
                    Text("已启用提醒：${rules.joinToString(" + ") { it.label }}", fontSize = 11.sp, color = IosOrange, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

// ====== Tab 4: 20周学期与 11 节作息时间自定义页 ======
@Composable
fun IosSettingsInlineTab(
    currentStartMonday: String,
    currentTotalWeeks: Int,
    currentSections: List<SectionTimeSlot>,
    onSave: (String, Int, List<SectionTimeSlot>) -> Unit
) {
    var startMondayStr by remember(currentStartMonday) { mutableStateOf(currentStartMonday) }
    var weeksStr by remember(currentTotalWeeks) { mutableStateOf(currentTotalWeeks.toString()) }
    var editableSections by remember(currentSections) { mutableStateOf(currentSections) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = IosCardBg,
            modifier = Modifier.fillMaxWidth().border(0.5.dp, IosSeparator, RoundedCornerShape(18.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("学期周数与第一周周一设置", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = IosLabelPrimary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startMondayStr,
                        onValueChange = { startMondayStr = it },
                        label = { Text("第一周周一 (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1.4f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = weeksStr,
                        onValueChange = { weeksStr = it },
                        label = { Text("总周数(默认20)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Text("全天 11 节作息（早8:10起 / 午14:30起 / 晚19:10起，改上课自动+45分钟下课）：", fontSize = 12.sp, color = IosLabelSecondary)
                editableSections.forEachIndexed { idx, slot ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${slot.periodGroup}第${slot.section}节", fontSize = 12.sp, modifier = Modifier.width(68.dp), fontWeight = FontWeight.Medium)
                        OutlinedTextField(
                            value = slot.start.toString(),
                            onValueChange = { newStart ->
                                runCatching { LocalTime.parse(newStart) }.getOrNull()?.let { parsed ->
                                    val copy = editableSections.toMutableList()
                                    copy[idx] = slot.copy(start = parsed, end = parsed.plusMinutes(45))
                                    editableSections = copy
                                }
                            },
                            label = { Text("上课") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = slot.end.toString(),
                            onValueChange = { newEnd ->
                                runCatching { LocalTime.parse(newEnd) }.getOrNull()?.let { parsed ->
                                    val copy = editableSections.toMutableList()
                                    copy[idx] = slot.copy(end = parsed)
                                    editableSections = copy
                                }
                            },
                            label = { Text("下课") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                Button(
                    onClick = { onSave(startMondayStr, weeksStr.toIntOrNull() ?: 20, editableSections) },
                    colors = ButtonDefaults.buttonColors(containerColor = IosBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("保存学期与 11 节作息设置", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun FullCourseAddDialog(
    initialCourse: CourseEntity? = null,
    totalWeeks: Int,
    defaultColorHex: String,
    onDismiss: () -> Unit,
    onDelete: (CourseEntity) -> Unit = {},
    onSave: (CourseEntity) -> Unit
) {
    val converters = remember { Converters() }
    val initialSlot = remember(initialCourse) {
        initialCourse?.let { converters.parseTimeSlots(it.timeSlotsJson).firstOrNull() }
    }
    var courseName by remember { mutableStateOf(initialCourse?.courseName ?: "") }
    var credits by remember { mutableStateOf(initialCourse?.credits ?: "") }
    var location by remember { mutableStateOf(initialCourse?.campusNote ?: "") }
    var teacherName by remember { mutableStateOf(initialCourse?.teacherName ?: "") }
    var studentCount by remember { mutableStateOf(initialCourse?.studentCount ?: "") }
    var majorAndClass by remember { mutableStateOf(initialCourse?.majorAndClass ?: "") }
    var notes by remember { mutableStateOf(initialCourse?.prepChecklist ?: "") }
    var selectedColor by remember { mutableStateOf(initialCourse?.colorHex ?: defaultColorHex) }

    var dayOfWeek by remember { mutableIntStateOf(initialSlot?.dayOfWeek ?: 1) }
    var startSection by remember { mutableIntStateOf(initialSlot?.startSection ?: 1) }
    var endSection by remember { mutableIntStateOf(initialSlot?.endSection ?: 2) }
    var selectedWeeks by remember { mutableStateOf(initialSlot?.weeks?.toSet() ?: (1..totalWeeks).toSet()) }

    // 9 档提醒选择状态（5分钟、10分钟、20分钟、30分钟、1小时、2小时、1天、2天、自定义）
    var selectedPresetIds by remember { mutableStateOf(setOf("p_2d", "p_30m")) }
    var showCustomInput by remember { mutableStateOf(false) }
    var customDays by remember { mutableStateOf("2") }
    var customHours by remember { mutableStateOf("0") }
    var customMinutes by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = IosSystemBg,
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF3C3C43).copy(alpha = 0.25f))
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (initialCourse == null) "添加课程 (iOS风格卡片)" else "编辑课程：${initialCourse.courseName}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = IosLabelPrimary
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("1. iOS 课程颜色（每门课自动分配不同颜色）：", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    COURSE_COLOR_PALETTE.forEach { hex ->
                        val isSel = selectedColor.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(hex)))
                                .border(
                                    width = if (isSel) 2.5.dp else 0.dp,
                                    color = if (isSel) IosLabelPrimary else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { selectedColor = hex }
                        )
                    }
                }

                OutlinedTextField(value = courseName, onValueChange = { courseName = it }, label = { Text("课程名称 *") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = credits, onValueChange = { credits = it }, label = { Text("学分") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = studentCount, onValueChange = { studentCount = it }, label = { Text("人数") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("地点(教室)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = teacherName, onValueChange = { teacherName = it }, label = { Text("老师") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = majorAndClass, onValueChange = { majorAndClass = it }, label = { Text("专业和班级") }, singleLine = true)
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("备注（上课注意事项等）") })

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = dayOfWeek.toString(),
                        onValueChange = { dayOfWeek = (it.toIntOrNull() ?: 1).coerceIn(1, 7) },
                        label = { Text("星期(1-7)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = startSection.toString(),
                        onValueChange = { startSection = (it.toIntOrNull() ?: 1).coerceIn(1, 11) },
                        label = { Text("起始节(1-11)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = endSection.toString(),
                        onValueChange = { endSection = (it.toIntOrNull() ?: startSection).coerceIn(startSection, 11) },
                        label = { Text("结束节(1-11)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Divider(color = IosSeparator)
                Text("2. 勾选上课周数 (1-$totalWeeks 周面板)：", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistChip(onClick = { selectedWeeks = (1..totalWeeks).toSet() }, label = { Text("1-${totalWeeks}全周") })
                    AssistChip(onClick = { selectedWeeks = (1..totalWeeks).filter { it % 2 == 1 }.toSet() }, label = { Text("单周") })
                    AssistChip(onClick = { selectedWeeks = (1..totalWeeks).filter { it % 2 == 0 }.toSet() }, label = { Text("双周") })
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.height(130.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(totalWeeks) { idx ->
                        val w = idx + 1
                        val isSelected = selectedWeeks.contains(w)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) IosBlue else Color.White)
                                .clickable {
                                    selectedWeeks = if (isSelected) selectedWeeks - w else selectedWeeks + w
                                }
                                .padding(vertical = 5.dp)
                        ) {
                            Text(if (isSelected) "✓${w}周" else "${w}周", fontSize = 11.sp, color = if (isSelected) Color.White else IosLabelPrimary)
                        }
                    }
                }

                Divider(color = IosSeparator)
                Text("3. 提醒时间（支持多选：5分/10分/20分/30分/1小时/2小时/1天/2天/自定义）：", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.height(115.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(AlarmScheduler.standardReminderPresets) { preset ->
                        val active = selectedPresetIds.contains(preset.id)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) IosOrange else Color.White)
                                .clickable {
                                    selectedPresetIds = if (active) selectedPresetIds - preset.id else selectedPresetIds + preset.id
                                }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(preset.label, fontSize = 11.sp, color = if (active) Color.White else IosLabelPrimary)
                        }
                    }
                    item {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (showCustomInput) IosBlue else Color.White)
                                .clickable { showCustomInput = !showCustomInput }
                                .padding(vertical = 6.dp)
                        ) {
                            Text("自定义", fontSize = 11.sp, color = if (showCustomInput) Color.White else IosBlue)
                        }
                    }
                }

                if (showCustomInput) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = customDays, onValueChange = { customDays = it }, label = { Text("提前天") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = customHours, onValueChange = { customHours = it }, label = { Text("小时") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = customMinutes, onValueChange = { customMinutes = it }, label = { Text("分钟") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                colors = ButtonDefaults.buttonColors(containerColor = IosBlue),
                shape = RoundedCornerShape(50),
                onClick = {
                    if (courseName.isBlank()) return@Button
                    val chosenRules = AlarmScheduler.standardReminderPresets
                        .filter { selectedPresetIds.contains(it.id) }
                        .toMutableList()
                    if (showCustomInput) {
                        val d = customDays.toIntOrNull() ?: 0
                        val h = customHours.toIntOrNull() ?: 0
                        val m = customMinutes.toIntOrNull() ?: 0
                        chosenRules.add(
                            ReminderRule(
                                id = UUID.randomUUID().toString(),
                                label = "自定义提前${d}天${h}小时${m}分",
                                mode = "RELATIVE",
                                daysBefore = d,
                                hoursBefore = h,
                                minutesBefore = m
                            )
                        )
                    }
                    val entity = CourseEntity(
                        id = initialCourse?.id ?: System.currentTimeMillis(),
                        courseName = courseName,
                        colorHex = selectedColor,
                        credits = credits,
                        campusNote = location,
                        teacherName = teacherName,
                        studentCount = studentCount,
                        majorAndClass = majorAndClass,
                        prepChecklist = notes,
                        timeSlotsJson = converters.toTimeSlotsJson(
                            listOf(
                                CourseTimeSlot(
                                    slotId = initialSlot?.slotId ?: UUID.randomUUID().toString(),
                                    dayOfWeek = dayOfWeek,
                                    startSection = startSection,
                                    endSection = endSection,
                                    weeks = selectedWeeks.sorted(),
                                    classroom = location,
                                    classGroup = majorAndClass
                                )
                            )
                        ),
                        remindersJson = converters.toRemindersJson(chosenRules)
                    )
                    onSave(entity)
                }
            ) {
                Text("保存课程", color = Color.White)
            }
        },
        dismissButton = {
            Row {
                if (initialCourse != null) {
                    TextButton(onClick = { onDelete(initialCourse) }) {
                        Text("删除", color = IosRed)
                    }
                }
                TextButton(onClick = onDismiss) { Text("取消", color = IosBlue) }
            }
        }
    )
}
