package com.teacher.schedule

import androidx.room.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * 提醒规则：支持 5分钟、10分钟、20分钟、30分钟、1小时、2小时、1天、2天 以及 自定义任意时间
 */
data class ReminderRule(
    val id: String,
    val label: String,               // 如："提前2天"、"课前30分钟"、"自定义提醒"
    val mode: String,                // "RELATIVE" 或 "FIXED_TIME"
    val daysBefore: Int = 0,         // 提前天数
    val hoursBefore: Int = 0,        // 提前小时数
    val minutesBefore: Int = 0,      // 提前分钟数
    val fixedHour: Int = 20,         // 固定时刻模式：几点
    val fixedMinute: Int = 0,        // 固定时刻模式：几分
    val enabled: Boolean = true
)

/**
 * 上课时间段（支持 1-20 周面板勾选）
 */
data class CourseTimeSlot(
    val slotId: String,
    val dayOfWeek: Int,              // 1=周一 ... 7=周日
    val startSection: Int,           // 开始节次 (1..11)
    val endSection: Int,             // 结束节次 (1..11)
    val weeks: List<Int>,            // 1..20 周面板勾选结果
    val classroom: String,           // 上课地点/教室
    val classGroup: String           // 专业和班级
)

/**
 * 课程完整实体：
 * 支持：课程名、不同颜色、学分、地点、老师、人数、专业和班级、备注（上课注意事项等）
 */
@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseName: String,
    val colorHex: String,            // 每门课程自动分配不同颜色
    val credits: String = "",        // 学分（如 "3.0"）
    val campusNote: String = "",     // 地点（如 "东区 教三-204"）
    val teacherName: String = "",    // 老师姓名
    val studentCount: String = "",   // 人数（如 "64人"）
    val majorAndClass: String = "",  // 专业和班级（如 "计算机科学与技术 2401-02班"）
    val prepChecklist: String = "",  // 备注（上课注意事项等）
    val timeSlotsJson: String,       // List<CourseTimeSlot> JSON
    val remindersJson: String,       // List<ReminderRule> JSON
    val skippedWeeksJson: String = "[]"
)

class Converters {
    private val gson = Gson()

    fun parseTimeSlots(json: String): List<CourseTimeSlot> {
        val type = object : TypeToken<List<CourseTimeSlot>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun toTimeSlotsJson(list: List<CourseTimeSlot>): String = gson.toJson(list)

    fun parseReminders(json: String): List<ReminderRule> {
        val type = object : TypeToken<List<ReminderRule>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun toRemindersJson(list: List<ReminderRule>): String = gson.toJson(list)
}

@Dao
interface CourseDao {
    @Query("SELECT * FROM courses ORDER BY id DESC")
    suspend fun getAllCourses(): List<CourseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity): Long

    @Delete
    suspend fun deleteCourse(course: CourseEntity)
}

@Database(entities = [CourseEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
}
