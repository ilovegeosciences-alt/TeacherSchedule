package com.teacher.schedule

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews

/**
 * 桌面小部件 / 卡片 (AppWidgetProvider)：
 * 在手机桌面实时展示：
 * 1. 当前教学周次与星期
 * 2. 今日 / 明日待授课程（节次、上下课时间、课程名、教室、班级）
 * 3. 最近一条“提前备课提醒”预警条（如：提前2天提醒 · 周三3-4节 高等数学）
 */
class CourseWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.teacher.schedule.ACTION_REFRESH_WIDGET") {
            updateAllWidgets(context)
        }
    }

    companion object {
        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CourseWidgetProvider::class.java))
            for (id in ids) {
                updateAppWidget(context, manager, id)
            }
        }

        fun requestPinWidgetToHomeScreen(context: Context): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val appWidgetManager = context.getSystemService(AppWidgetManager::class.java)
                if (appWidgetManager != null && appWidgetManager.isRequestPinAppWidgetSupported) {
                    val provider = ComponentName(context, CourseWidgetProvider::class.java)
                    return appWidgetManager.requestPinAppWidget(provider, null, null)
                }
            }
            return false
        }

        private fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_teacher_schedule)

            // 点击卡片打开主程序
            val openAppIntent = Intent(context, MainActivity::class.java)
            val pendingOpen = PendingIntent.getActivity(
                context,
                0,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRootContainer, pendingOpen)

            // 填充桌面卡片展示信息
            views.setTextViewText(R.id.widgetHeaderTitle, "师刻课表 · 第 7 周")
            views.setTextViewText(R.id.widgetNextPrepAlert, "🔔 提前2天备课：周三 3-4节(10:10) 高等数学 @ 教三-204")
            views.setTextViewText(
                R.id.widgetTodayCoursesText,
                "• 今日 1-2节 (08:10-09:50) 高等数学(上) | 东区 教三-204 | 计科2401-02班
" +
                "• 周四 5-7节 (14:30-17:15) 机器学习导论 | 西区 信息楼-402 | 人工智能2301班"
            )

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
