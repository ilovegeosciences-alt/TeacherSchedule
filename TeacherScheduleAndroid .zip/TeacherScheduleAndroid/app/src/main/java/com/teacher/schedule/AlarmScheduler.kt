package com.teacher.schedule

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

data class SectionTimeSlot(
    val section: Int,
    val periodGroup: String, // "上午" | "下午" | "晚上"
    val start: LocalTime,
    val end: LocalTime
)

object AlarmScheduler {

    /**
     * 精确匹配需求的默认 11 节作息时间表（每节课 45 分钟，且支持自行修改）：
     * - 上午 4 节（08:10 开始；1-2节课间5分钟，2-3节大课间30分钟，3-4节课间5分钟）：
     *   第1节 08:10 - 08:55
     *   第2节 09:00 - 09:45
     *   第3节 10:15 - 11:00
     *   第4节 11:05 - 11:50
     * - 下午 4 节（14:30 开始；5-6节课间5分钟，6-7节大课间20分钟，7-8节课间5分钟）：
     *   第5节 14:30 - 15:15
     *   第6节 15:20 - 16:05
     *   第7节 16:25 - 17:10
     *   第8节 17:15 - 18:00
     * - 晚上 3 节（19:10 开始；9-11节之间均为5分钟课间）：
     *   第9节  19:10 - 19:55
     *   第10节 20:00 - 20:45
     *   第11节 20:50 - 21:35
     */
    val default11Sections = listOf(
        // 上午 1-4 节
        SectionTimeSlot(1, "上午", LocalTime.of(8, 10), LocalTime.of(8, 55)),
        SectionTimeSlot(2, "上午", LocalTime.of(9, 0), LocalTime.of(9, 45)),
        SectionTimeSlot(3, "上午", LocalTime.of(10, 15), LocalTime.of(11, 0)),
        SectionTimeSlot(4, "上午", LocalTime.of(11, 5), LocalTime.of(11, 50)),
        // 下午 5-8 节
        SectionTimeSlot(5, "下午", LocalTime.of(14, 30), LocalTime.of(15, 15)),
        SectionTimeSlot(6, "下午", LocalTime.of(15, 20), LocalTime.of(16, 5)),
        SectionTimeSlot(7, "下午", LocalTime.of(16, 25), LocalTime.of(17, 10)),
        SectionTimeSlot(8, "下午", LocalTime.of(17, 15), LocalTime.of(18, 0)),
        // 晚上 9-11 节
        SectionTimeSlot(9, "晚上", LocalTime.of(19, 10), LocalTime.of(19, 55)),
        SectionTimeSlot(10, "晚上", LocalTime.of(20, 0), LocalTime.of(20, 45)),
        SectionTimeSlot(11, "晚上", LocalTime.of(20, 50), LocalTime.of(21, 35))
    )

    /**
     * 9 项标准提醒选项预设：5分钟、10分钟、20分钟、30分钟、1小时、2小时、1天、2天、自定义
     */
    val standardReminderPresets = listOf(
        ReminderRule("p_5m", "课前5分钟", "RELATIVE", 0, 0, 5),
        ReminderRule("p_10m", "课前10分钟", "RELATIVE", 0, 0, 10),
        ReminderRule("p_20m", "课前20分钟", "RELATIVE", 0, 0, 20),
        ReminderRule("p_30m", "课前30分钟", "RELATIVE", 0, 0, 30),
        ReminderRule("p_1h", "课前1小时", "RELATIVE", 0, 1, 0),
        ReminderRule("p_2h", "课前2小时", "RELATIVE", 0, 2, 0),
        ReminderRule("p_1d", "提前1天", "RELATIVE", 1, 0, 0),
        ReminderRule("p_2d", "提前2天", "RELATIVE", 2, 0, 0)
    )

    fun getSectionStartMap(customSections: List<SectionTimeSlot> = default11Sections): Map<Int, LocalTime> {
        return customSections.associate { it.section to it.start }
    }

    fun getSectionEndMap(customSections: List<SectionTimeSlot> = default11Sections): Map<Int, LocalTime> {
        return customSections.associate { it.section to it.end }
    }

    fun calculateTriggerMillis(
        semesterStartMonday: LocalDate,
        weekNumber: Int,
        dayOfWeek: Int,
        startSection: Int,
        rule: ReminderRule,
        sectionStartMap: Map<Int, LocalTime> = getSectionStartMap()
    ): Long {
        val classDate = semesterStartMonday
            .plusWeeks((weekNumber - 1).toLong())
            .plusDays((dayOfWeek - 1).toLong())
        val classStartTime = sectionStartMap[startSection] ?: LocalTime.of(8, 10)
        val classDateTime = LocalDateTime.of(classDate, classStartTime)

        val triggerDateTime = if (rule.mode == "FIXED_TIME") {
            LocalDateTime.of(
                classDate.minusDays(rule.daysBefore.toLong()),
                LocalTime.of(rule.fixedHour, rule.fixedMinute)
            )
        } else {
            classDateTime
                .minusDays(rule.daysBefore.toLong())
                .minusHours(rule.hoursBefore.toLong())
                .minusMinutes(rule.minutesBefore.toLong())
        }

        return triggerDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val courseName = intent.getStringExtra("COURSE_NAME") ?: "课程提醒"
        val classroom = intent.getStringExtra("CLASSROOM") ?: ""
        val classGroup = intent.getStringExtra("CLASS_GROUP") ?: ""
        val weekNum = intent.getIntExtra("WEEK_NUM", 1)
        val startSec = intent.getIntExtra("START_SECTION", 1)
        val endSec = intent.getIntExtra("END_SECTION", 2)
        val ruleLabel = intent.getStringExtra("RULE_LABEL") ?: "课前提醒"
        val prepNote = intent.getStringExtra("PREP_NOTE") ?: ""

        val channelId = "teacher_course_reminder_channel"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "教师授课与备课提醒",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "支持5分钟/10分钟/20分钟/30分钟/1小时/2小时/1天/2天/自定义提醒"
                enableVibration(true)
            }
            nm.createNotificationChannel(channel)
        }

        val detailText = buildString {
            append("第${weekNum}周 · 第${startSec}-${endSec}节")
            if (classroom.isNotBlank()) append(" | 地点：$classroom")
            if (classGroup.isNotBlank()) append(" | 专业班级：$classGroup")
            if (prepNote.isNotBlank()) append("
备注/注意事项：$prepNote")
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("【$ruleLabel】$courseName")
            .setContentText(detailText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detailText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        nm.notify(System.currentTimeMillis().toInt(), notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        CourseWidgetProvider.updateAllWidgets(context)
    }
}
