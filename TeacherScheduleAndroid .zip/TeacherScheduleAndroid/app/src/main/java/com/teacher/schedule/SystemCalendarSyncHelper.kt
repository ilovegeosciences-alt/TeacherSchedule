package com.teacher.schedule

import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.TimeZone

/**
 * 安卓系统日历直连同步器 (CalendarContract)：
 * 一键将教师本学期的排课以及“提前2天备课提醒 / 任意时间提醒”直接写入手机自带系统日历。
 * 优势：
 * 1. 依托安卓系统自带日历底层唤醒，无惧国产 ROM (MIUI/HyperOS/HarmonyOS/OriginOS/ColorOS) 杀后台。
 * 2. 支持任意分钟数的提前提醒（例如提前 2 天 = 2880 分钟，或提前 N 天晚上 20:00 折算的精确分钟偏移）。
 */
object SystemCalendarSyncHelper {

    private const val SYNC_TAG_PREFIX = "[师刻课表同步]"

    /**
     * 查找手机默认主日历账户 ID
     */
    private fun findPrimaryCalendarId(context: Context): Long? {
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.IS_PRIMARY,
            CalendarContract.Calendars.VISIBLE
        )
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            "${CalendarContract.Calendars.VISIBLE} = 1",
            null,
            null
        )?.use { cursor ->
            var fallbackId: Long? = null
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                val isPrimary = cursor.getInt(1) == 1
                if (isPrimary) return id
                if (fallbackId == null) fallbackId = id
            }
            return fallbackId
        }
        return null
    }

    /**
     * 先清理之前由本应用同步过的旧日程，避免重复创建
     */
    fun clearPreviouslySyncedEvents(context: Context) {
        context.contentResolver.delete(
            CalendarContract.Events.CONTENT_URI,
            "${CalendarContract.Events.DESCRIPTION} LIKE ?",
            arrayOf("%$SYNC_TAG_PREFIX%")
        )
    }

    /**
     * 将所有课程及对应的任意提前提醒写入系统日历
     * @return 成功写入的课次总数
     */
    fun syncCoursesToSystemCalendar(
        context: Context,
        courses: List<CourseEntity>,
        semesterStartMonday: LocalDate,
        sections: List<SectionTimeSlot> = AlarmScheduler.default11Sections
    ): Int {
        val calendarId = findPrimaryCalendarId(context) ?: return 0
        clearPreviouslySyncedEvents(context)

        val converters = Converters()
        val startMap = AlarmScheduler.getSectionStartMap(sections)
        val endMap = AlarmScheduler.getSectionEndMap(sections)
        var syncedCount = 0

        for (course in courses) {
            val slots = converters.parseTimeSlots(course.timeSlotsJson)
            val reminders = converters.parseReminders(course.remindersJson).filter { it.enabled }

            for (slot in slots) {
                val secStart = startMap[slot.startSection] ?: LocalTime.of(8, 10)
                val secEnd = endMap[slot.endSection] ?: secStart.plusMinutes(45)

                for (week in slot.weeks) {
                    val classDate = semesterStartMonday
                        .plusWeeks((week - 1).toLong())
                        .plusDays((slot.dayOfWeek - 1).toLong())

                    val startDateTime = LocalDateTime.of(classDate, secStart)
                    val endDateTime = LocalDateTime.of(classDate, secEnd)
                    val startMillis = startDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    val endMillis = endDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

                    val eventValues = ContentValues().apply {
                        put(CalendarContract.Events.DTSTART, startMillis)
                        put(CalendarContract.Events.DTEND, endMillis)
                        put(CalendarContract.Events.TITLE, "[授课] ${course.courseName} (${slot.classGroup.ifBlank { "第${week}周" }})")
                        put(CalendarContract.Events.EVENT_LOCATION, slot.classroom)
                        put(
                            CalendarContract.Events.DESCRIPTION,
                            "$SYNC_TAG_PREFIX 第${week}周 第${slot.startSection}-${slot.endSection}节
" +
                                "授课班级：${slot.classGroup}
" +
                                "备课备注：${course.prepChecklist}"
                        )
                        put(CalendarContract.Events.CALENDAR_ID, calendarId)
                        put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                        put(CalendarContract.Events.HAS_ALARM, if (reminders.isNotEmpty()) 1 else 0)
                    }

                    val eventUri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, eventValues)
                    val eventId = eventUri?.lastPathSegment?.toLongOrNull() ?: continue
                    syncedCount++

                    // 插入任意提前时间提醒 (支持提前2天固定时刻 或 提前任意天/小时/分钟)
                    for (rule in reminders) {
                        val minutesBefore = if (rule.mode == "FIXED_TIME") {
                            val triggerDt = LocalDateTime.of(
                                classDate.minusDays(rule.daysBefore.toLong()),
                                LocalTime.of(rule.fixedHour, rule.fixedMinute)
                            )
                            Duration.between(triggerDt, startDateTime).toMinutes().toInt().coerceAtLeast(0)
                        } else {
                            (rule.daysBefore * 24 * 60) + (rule.hoursBefore * 60) + rule.minutesBefore
                        }

                        val reminderValues = ContentValues().apply {
                            put(CalendarContract.Reminders.EVENT_ID, eventId)
                            put(CalendarContract.Reminders.MINUTES, minutesBefore)
                            put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
                        }
                        context.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminderValues)
                    }
                }
            }
        }
        return syncedCount
    }
}
